
import { NextRequest, NextResponse } from 'next/server';
import { myProvider } from '@/lib/ai/providers';

export async function POST(req: NextRequest, { params }: { params: { type: string } }) {
  const body = await req.json();
  const { prompt, gpt } = body;
  const { type } = params;

  try {
    let result;

    if (gpt && type === 'text') {
      const enrichedPrompt = `Eres un GPT personalizado llamado ${gpt}. Responde como fue configurado el perfil de ${gpt}. Aquí va el mensaje: ${prompt}`;
      result = await myProvider.languageModels['artifact-model'].generate({ prompt: enrichedPrompt });
      return NextResponse.json(result);
    }

    switch (type) {
      case 'text':
        result = await myProvider.languageModels['artifact-model'].generate({ prompt });
        break;
      case 'image':
        result = await myProvider.imageModels['default-image'].generate({ prompt });
        break;
      case 'audio':
        result = await myProvider.audioModels['tts-model'].generate({ prompt });
        break;
      default:
        return NextResponse.json({ error: 'Tipo no soportado' }, { status: 400 });
    }

    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json({ error: err.message || 'Error procesando el contenido' }, { status: 500 });
  }
}
