
'use client';

import { useEffect, useState } from 'react';

export default function HubbaUnlockedPage() {
  const [isVerified, setIsVerified] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  const handleVerify = () => {
    setIsVerified(true);
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: 'Tú', text: input };
    setMessages([...messages, userMessage]);

    const res = await fetch('/api/generate/text', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: `NSFW: ${input}`, gpt: 'HubbaUnlocked' })
    });

    const data = await res.json();
    const aiMessage = { sender: 'Hubba X', text: data?.text || '...' };
    setMessages((prev) => [...prev, aiMessage]);
    setInput('');
  };

  return (
    <div className="bg-black text-white min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">🔓 Hubba Unlocked</h1>
      {!isVerified ? (
        <div className="bg-gray-900 p-4 rounded">
          <p className="mb-2">Este módulo contiene contenido sensible y para adultos. ¿Confirmas que eres mayor de 18 años?</p>
          <button onClick={handleVerify} className="bg-purple-700 px-4 py-2 rounded">
            Confirmar y Entrar
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-gray-800 p-4 rounded h-64 overflow-y-auto">
            {messages.map((msg, i) => (
              <div key={i} className="mb-2">
                <strong className="text-purple-400">{msg.sender}:</strong> <span>{msg.text}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 p-2 rounded bg-gray-700 text-white"
              placeholder="Escribe tu fantasía o pregunta aquí..."
            />
            <button onClick={sendMessage} className="bg-purple-700 px-4 py-2 rounded">
              Enviar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
