export type DataPart = { type: 'append-message'; message: string };
