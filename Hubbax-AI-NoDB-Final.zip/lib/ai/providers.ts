
import { customProvider } from 'ai';

const HF_API_KEY = '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';

const endpoints = {
  general: 'https://api-inference.huggingface.co/models/mistralai/Mixtral-8x7B-Instruct-v0.1',
  code: 'https://api-inference.huggingface.co/models/deepseek-ai/deepseek-coder-6.7b',
  dialog: 'https://api-inference.huggingface.co/models/openchat/openchat-3.5-0106',
  imageReal: 'https://api-inference.huggingface.co/models/SG161222/Realistic_Vision_V5.1',
  tts: 'https://api-inference.huggingface.co/models/suno/bark',
  qwen: 'https://api-inference.huggingface.co/models/Qwen/Qwen2.5-Omni-7B',
  seamless: 'https://api-inference.huggingface.co/models/facebook/seamless-m4t-v2-large',
  llava: 'https://api-inference.huggingface.co/models/llava-hf/llava-1.5-7b-hf'
};

async function queryHF(endpoint: string, inputs: any) {
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${HF_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ inputs }),
  });
  return await response.json();
}

export const myProvider = customProvider({
  languageModels: {
    'artifact-model': {
      async generate({ prompt }) {
        let endpoint = endpoints.general;
        if (prompt.includes('function') || prompt.includes('import')) {
          endpoint = endpoints.code;
        } else if (prompt.length < 120) {
          endpoint = endpoints.dialog;
        }
        const result = await queryHF(endpoint, prompt);
        return { text: result?.[0]?.generated_text || 'Respuesta vacía' };
      },
    },
    'qwen-omni': {
      async generate({ prompt }) {
        const result = await queryHF(endpoints.qwen, prompt);
        return { text: result?.[0]?.generated_text || 'Respuesta Qwen vacía' };
      }
    },
  },
  imageModels: {
    'default-image': {
      async generate({ prompt }) {
        const result = await queryHF(endpoints.imageReal, prompt);
        return result;
      },
    },
  },
  audioModels: {
    'tts-model': {
      async generate({ prompt }) {
        const result = await queryHF(endpoints.tts, prompt);
        return result;
      },
    },
    'seamless': {
      async generate({ prompt }) {
        const result = await queryHF(endpoints.seamless, prompt);
        return result;
      },
    },
  },
  visionModels: {
    'llava-model': {
      async generate({ prompt }) {
        const result = await queryHF(endpoints.llava, prompt);
        return result;
      },
    },
  },
});
